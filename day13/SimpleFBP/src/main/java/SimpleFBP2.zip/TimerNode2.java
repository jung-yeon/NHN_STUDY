public class TimerNode2 extends InputNode2{
    private long interval;
    Thread thread;
    public long startTime;
    public TimerNode2(long interval){
        this.interval = interval;
        this.thread = new Thread();
        this.startTime = System.currentTimeMillis();
    }
    public synchronized void main(){
        try{
            thread.start();
            thread.sleep(this.interval);
            thread.interrupt();

        }catch (Exception e){

        }
    }
}
