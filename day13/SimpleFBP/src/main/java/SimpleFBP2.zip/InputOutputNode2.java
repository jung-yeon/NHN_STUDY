public class InputOutputNode2 extends ActiveNode{
    private final InputPort[] inputPorts;
    private final InputPort[] peerInputPorts;
    protected  InputOutputNode2(){
        this.inputPorts = new InputPort[10];
        this.peerInputPorts = new InputPort[10];
    }

    protected InputOutputNode2(int inputCount, int outputCount){
        this.inputPorts = new InputPort[inputCount];
        this.peerInputPorts = new InputPort[outputCount];
    }


    public void connect(int index, InputPort port){
//        for(int i = 0; i < peerInputPorts.length; i++){
//            peerInputPorts[i] = port; // ???
//        }
        if(index < this.peerInputPorts.length){
            this.peerInputPorts[index] = port;
        }else{
            throw new IndexOutOfBoundsException();
        }
    }

    public int getInputPortCount(){
        return this.inputPorts.length;
    }

    public InputPort getInputPort(int index){
        if(this.inputPorts[index] != null) {
            return this.inputPorts[index];
        }else{
            return null;
        }
    }
    public void output(Message message){
        for(int i = 0; i < peerInputPorts.length; i++){
            if(peerInputPorts[i] == null ){
                peerInputPorts[i].put(message);
            }
        }
    }
}
