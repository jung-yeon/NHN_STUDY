import java.util.Scanner;

public class AdditionNode2 extends InputOutputNode2{
    Message message;
    private int count;
    private final InputPort[] peerInputPorts;

    public AdditionNode2(){
        super();
        this.peerInputPorts = new InputPort[10];
    }

    protected AdditionNode2(int count, int count2) {
        super(count,count2);
        this.count = count;
        this.peerInputPorts = new InputPort[10];
    }

    @Override
    public InputPort getInputPort(int index) {
        return super.getInputPort(index);
    }

    public synchronized void main(){
        int sum = 0;
        for(int i = 0; i < this.getInputPortCount(); i++){
            while(this.getInputPort(i) != null && this.getInputPort(i).hasMessage()){
                sum += (Integer)this.getInputPort(i).get().getPayload();
                this.peerInputPorts[i] = this.getInputPort(i);
                this.getInputPort(i).remove();
            }

            }
        }

    public void connect(int index, InputPort port) {
        if(index < this.peerInputPorts.length){
            this.peerInputPorts[index] = port;
        }else{
            throw new IndexOutOfBoundsException();
        }
    }



}
