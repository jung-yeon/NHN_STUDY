//public class InputNode extends ActiveNode{
//    public ActiveNode node;
//    private OutputSocket [] outputSockets;
//    public InputNode(int count){
//        this.outputSockets[count] = node;
//    }
//    public int getOutputSocketCount(){
//        return outputSockets.length;
//    }
//    public OutputSocket getOutputSocket(int index){
//        return outputSockets[index];
//    }
//    public void output(Message message){}
//}
