public class TestInOutput {
    public static void main(String[] args) {

    }
}
