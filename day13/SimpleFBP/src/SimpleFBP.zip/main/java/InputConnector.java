public interface InputConnector {
    void put(Message message);
}
