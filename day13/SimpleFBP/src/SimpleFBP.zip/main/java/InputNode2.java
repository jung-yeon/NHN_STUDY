public abstract class InputNode2 extends ActiveNode{

    private final InputPort[] peerInputPorts;
    protected InputNode2(String name, int count){
        super(name);
        this.peerInputPorts = new InputPort[count];
    }
    public InputNode2(){
        super();
        this.peerInputPorts = new InputPort[10];
    }


    public void connect(int index, InputPort port){
//        for(int i = 0; i < peerInputPorts.length; i++){
//            peerInputPorts[i] = port; // ???
//        }
        if(index < this.peerInputPorts.length){
            this.peerInputPorts[index] = port;
        }else{
            throw new IndexOutOfBoundsException();
        }
    }
    public void output(Message message){
//        for(int i = 0; i < peerInputPorts.length; i++){
//            if(peerInputPorts[i] != null){
//                peerInputPorts[i].put(message);
//            }
//        }
        for(InputPort port : this.peerInputPorts){
            if(port != null){
                port.put(message);
            }
        }
    }
}
