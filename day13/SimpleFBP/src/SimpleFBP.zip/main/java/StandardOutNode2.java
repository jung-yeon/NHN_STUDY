public class StandardOutNode2 extends OutputNode2{
    private int count;
    public StandardOutNode2(){
        super();
    }
    public StandardOutNode2(int count){
        super(count);
        this.count = count;
    }

    @Override
    public synchronized void main(){
        for(int i = 0; i < count; i++){
            while(this.getInputPorts(i) != null && this.getInputPorts(i).hasMessage()){
                System.out.println("output : " + this.getInputPorts(i).get().getPayload());
                this.getInputPorts(i).remove();
            }
        }

    }
}
