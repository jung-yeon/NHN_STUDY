import java.util.Scanner;

public class RNGNode2 extends InputNode2{
    private int num;
    //private final InputPort[] peerInputPorts;
    Message message;
    private int count;
    public RNGNode2(){
        super();
    }

    protected RNGNode2(int count) {
        //super(count);
        this.count = count;
    }
    @Override
    public synchronized void main(){
        this.message = new Message(this.count);
        this.output(message);
    }
}

